#ifndef CARSYSTEM_H
#define CARSYSTEM_H

#include <include/Pipeline.h>
#include <QString>
#include <QTextCodec>
#include <QDebug>

class CarSystem
{
public:
    CarSystem();
    QString usingDevice();

private:
    pr::PipelinePR *carPrc;
    QString pPath;
};

#endif // CARSYSTEM_H
