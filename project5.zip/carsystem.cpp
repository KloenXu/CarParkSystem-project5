#include "carsystem.h"

CarSystem::CarSystem()
{
    carPrc = new pr::PipelinePR("model/cascade.xml",
                                "model/HorizonalFinemapping.prototxt","model/HorizonalFinemapping.caffemodel",
                                "model/Segmentation.prototxt","model/Segmentation.caffemodel",
                                "model/CharacterRecognization.prototxt","model/CharacterRecognization.caffemodel",
                                "model/SegmenationFree-Inception.prototxt","model/SegmenationFree-Inception.caffemodel");
    pPath = "temp.jpg";
}

QString CarSystem::usingDevice()
{
    //识别图片
    //识别--pPath是成员变量保存车头照片路径
    cv::Mat plateImage = cv::imread(pPath.toUtf8().data());//要识别的车牌照片路径（要清晰，正面）
    //定义一个容器存放识别结果
    //RunPiplineAsImage()根据你提供的车牌照片识别车牌
    std::vector<pr::PlateInfo> res = carPrc->RunPiplineAsImage(plateImage,pr::SEGMENTATION_FREE_METHOD);
    float conf = 0;
    //保存识别的车牌号码
    std::string plateNumber = "";
    //新式for循环
    for (pr::PlateInfo st : res) {
        if (st.confidence>0.90)  //判断识别率，识别结果中识别率高于90%
        {
            plateNumber = st.getPlateName();  //获取识别的车牌字符串
            //打印车牌字符串，打印识别率
            std::cout << st.getPlateName() << " " << st.confidence << std::endl;
            conf += st.confidence;
        }
    }

    //qDebug()<< QString::fromLocal8Bit(plateNumber.c_str());
    //ui->label_2->setText(QString::fromLocal8Bit(plateNumber.c_str()));

    QTextCodec *codec=QTextCodec::codecForName("gbk");

    QString str=codec->toUnicode(plateNumber.c_str());//这个str就是获得的车牌
    qDebug()<<str;
    return str;
}
